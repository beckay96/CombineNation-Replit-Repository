
export interface FamilyMember {
  id: string;
  name: string;
  email: string;
  relationship: 'Spouse' | 'Child' | 'Guardian';
}

export interface SpouseInfo {
  display_name: string;
  email: string;
  makeParentToChildren: boolean;
}

export interface ChildInfo {
  firstName: string;
  middleName: string;
  lastName: string;
  hasEmail: boolean;
  email: string;
  password: string;
  confirmPassword: string;
  dob: string;
}
