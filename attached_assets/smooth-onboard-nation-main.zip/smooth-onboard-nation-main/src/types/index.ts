
import type { Database } from '@/integrations/supabase/types';

export interface UserProfile {
  id: string;
  theme: 'light' | 'dark';
  neon_mode?: boolean;
  created_time?: string;
  last_active_time?: string;
  display_name?: string;
  first_name?: string;
  middle_names?: string;
  last_name?: string;
  dob?: Date;
}

// Database types
export type Tables = Database['public']['Tables'];
export type ProfileRow = Tables['profiles']['Row'];
