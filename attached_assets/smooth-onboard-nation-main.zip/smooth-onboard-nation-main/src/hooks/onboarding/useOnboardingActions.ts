
// This file is now just a re-export from the actions directory
// to maintain backward compatibility during refactoring
import { useOnboardingActions } from './actions';
export { useOnboardingActions };
