
import { useOnboardingState } from './useOnboardingState';
import { useOnboardingSteps } from './useOnboardingSteps';
import { useOnboardingActions } from './useOnboardingActions';
import { useAuth } from '@/hooks/auth';

export function useOnboarding(onComplete: () => void, initialStep: number = 0) {
  const { 
    email, setEmail,
    password, setPassword,
    confirmPassword, setConfirmPassword,
    displayName, setDisplayName,
    step, setStep,
    selectedOptionIndex, setSelectedOptionIndex,
    isProcessing, setIsProcessing,
    accountExists, setAccountExists,
    activeAuthTab, setActiveAuthTab,
    resetFormFields
  } = useOnboardingState(initialStep);

  const { getSteps } = useOnboardingSteps();
  const { isLoading: authLoading } = useAuth();

  const {
    handleRoleSelect,
    handleNext,
    handleBack,
    handleSignup,
    handleProfileSubmit,
    handleFamilySetupComplete,
    handleSchoolSetupComplete
  } = useOnboardingActions(
    email,
    setEmail,
    password,
    setPassword,
    confirmPassword,
    setConfirmPassword,
    displayName,
    setDisplayName,
    step,
    setStep,
    selectedOptionIndex,
    setSelectedOptionIndex,
    isProcessing,
    setIsProcessing,
    accountExists,
    setAccountExists,
    getSteps,
    onComplete,
    resetFormFields
  );

  return {
    email,
    setEmail,
    password,
    setPassword,
    confirmPassword,
    setConfirmPassword,
    displayName,
    setDisplayName,
    step,
    selectedOptionIndex,
    isProcessing,
    isLoading: authLoading,
    accountExists,
    activeAuthTab,
    getSteps,
    handleRoleSelect,
    handleNext,
    handleBack,
    handleSignup,
    handleProfileSubmit,
    handleFamilySetupComplete,
    handleSchoolSetupComplete
  };
}

export * from './types';
