
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { UserProfile } from '@/types';

interface ProfileCheckResult {
  checkingProfileStatus: boolean;
  needsDisplayName: boolean;
  profileSetupComplete: boolean;
  setProfileSetupComplete: (complete: boolean) => void;
  handleOnboardingComplete: () => void;
}

export function useProfileCheck(
  isAuthenticated: boolean,
  userProfile: UserProfile | null,
  authLoading: boolean
): ProfileCheckResult {
  const [checkingProfileStatus, setCheckingProfileStatus] = useState(false);
  const [needsDisplayName, setNeedsDisplayName] = useState(false);
  const [profileSetupComplete, setProfileSetupComplete] = useState(false);
  const [maxProfileCheckAttempts, setMaxProfileCheckAttempts] = useState(3);
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Track mount state to avoid state updates after unmount
    let isMounted = true;
    let timeoutId: NodeJS.Timeout; // Declare timeoutId at the outer scope so it's available throughout the effect
    
    const checkProfile = async () => {
      // Return early if conditions aren't met
      if (checkingProfileStatus || profileSetupComplete || !isAuthenticated || !userProfile?.id) {
        return;
      }

      const timeoutPromise = new Promise((_, reject) => {
        timeoutId = setTimeout(() => reject(new Error('Profile update timed out')), 4000);
      });
      
      // Only proceed if we're authenticated and have a profile
      if (!isAuthenticated || !userProfile?.id) {
        console.log('useProfileCheck: Not checking profile - not authenticated or no profile', { 
          isAuthenticated, 
          hasProfile: !!userProfile,
          userProfileId: userProfile?.id
        });
        if (isMounted) {
          setCheckingProfileStatus(false);
        }
        return;
      }
      
      console.log('useProfileCheck: Checking profile status', { 
        isAuthenticated, 
        hasUserProfile: !!userProfile, 
        userProfileId: userProfile.id 
      });
      
      try {
        if (isMounted) {
          setCheckingProfileStatus(true);
        }

        // Race between profile check and timeout
        const { data, error } = await Promise.race([
          supabase
            .from('profiles')
            .select('first_name, profile_set_up_complete, display_name')
            .eq('id', userProfile.id)
            .maybeSingle()
        ]);
        
        if (error) {
          console.error('useProfileCheck: Error checking profile:', error);
          if (isMounted) {
            setCheckingProfileStatus(false);
            
            // Decrement attempts counter to break out of potential loops
            setMaxProfileCheckAttempts(prev => prev - 1);
            
            if (maxProfileCheckAttempts <= 0) {
              // Show a toast when we give up
              toast({
                title: "Profile check failed",
                description: "Unable to check your profile after several attempts. Please try refreshing the page.",
                variant: "destructive"
              });
            }
          }
          return;
        }
        
        // If data is null, profile doesn't exist yet
        if (!data) {
          console.log('useProfileCheck: Profile not found in database, needs setup');
          if (isMounted) {
            setNeedsDisplayName(true);
            setProfileSetupComplete(false);
            setCheckingProfileStatus(false);
          }
          return;
        }
        
        // Check if first_name is missing - this is what determines if we need to show the profile details step
        const firstNameMissing = !data.first_name;
        
        console.log('useProfileCheck: Profile check result:', { 
          firstNameMissing, 
          firstName: data.first_name,
          displayName: data.display_name,
          profileSetUpComplete: data.profile_set_up_complete
        });
        
        if (isMounted) {
          // If first_name is missing, we need to show the profile details form
          setNeedsDisplayName(firstNameMissing);
          
          // We have a display_name but no first_name, this means they're in the middle of the onboarding flow
          if (data.display_name && firstNameMissing) {
            console.log('useProfileCheck: User has display_name but no first_name, continuing onboarding');
            setNeedsDisplayName(true);
            setProfileSetupComplete(false);
          } else {
            // Use the profile_set_up_complete flag directly from the database
            // Only consider profile complete if first_name is present
            setProfileSetupComplete(data.profile_set_up_complete && !firstNameMissing);
          }
          
          setCheckingProfileStatus(false);
          clearTimeout(timeoutId);
        }
      } catch (error) {
        console.error('useProfileCheck: Error checking profile status:', error);
        if (error.message === 'Profile update timed out') {
          toast({
            title: "Profile Check Timeout",
            description: "Profile check took too long. Please refresh the page.",
            variant: "destructive"
          });
        }
        if (isMounted) {
          toast({
            title: "Error checking profile",
            description: "We couldn't check your profile status. Please try again.",
            variant: "destructive"
          });
          // If there's an error, assume profile is not complete
          setProfileSetupComplete(false);
          setCheckingProfileStatus(false);
          
          // Decrement attempts counter to break out of potential loops
          setMaxProfileCheckAttempts(prev => prev - 1);
        }
      }
    };

    // Only check once auth is ready and we haven't checked yet
    if (!authLoading && !checkingProfileStatus && !profileSetupComplete) {
      checkProfile();
    }

    return () => {
      isMounted = false;
      clearTimeout(timeoutId);
    };
  }, [isAuthenticated, userProfile, authLoading, toast, maxProfileCheckAttempts]);

  // Add a safety timeout to prevent infinite loading
  useEffect(() => {
    // If we're still in loading state after 5 seconds, force exit loading
    const safetyTimeout = setTimeout(() => {
      if (checkingProfileStatus) {
        console.log('useProfileCheck: Safety timeout triggered, forcing exit from loading state');
        setCheckingProfileStatus(false);
        
        toast({
          title: "Loading timeout",
          description: "Profile check took too long. Showing default view.",
          variant: "destructive"
        });
      }
    }, 4000); // Reduced to 4 seconds for faster feedback
    
    return () => clearTimeout(safetyTimeout);
  }, [checkingProfileStatus, toast]);

  const handleOnboardingComplete = () => {
    console.log('useProfileCheck: Onboarding completed');
    setOnboardingComplete(true);
    setProfileSetupComplete(true);
    setNeedsDisplayName(false);
  };

  return {
    checkingProfileStatus,
    needsDisplayName,
    profileSetupComplete,
    setProfileSetupComplete,
    handleOnboardingComplete
  };
}
