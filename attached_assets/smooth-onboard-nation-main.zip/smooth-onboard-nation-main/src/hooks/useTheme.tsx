import React, { createContext, useState, useEffect, ReactNode, useContext } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface ThemeContextType {
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
}

interface ThemeProviderProps {
  children: ReactNode;
  defaultTheme?: 'light' | 'dark';
  storageKey?: string;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider = ({ children, defaultTheme = 'dark', storageKey = 'neonMode' }: ThemeProviderProps) => {
  const [theme, setTheme] = useState<'light' | 'dark'>(defaultTheme);

  useEffect(() => {
    const fetchUserThemePreference = async () => {
      try {
        const { data: sessionData } = await supabase.auth.getSession();
        const session = sessionData?.session;

        if (session && session.user) {
          const { data, error } = await supabase
            .from('profiles')
            .select('neon_mode')
            .eq('id', session.user.id)
            .single();
          
          if (error) {
            console.error('Error fetching neon/light mode preference:', error);
            return;
          }
          
          if (data && data.neon_mode !== null) {
            setTheme(data.neon_mode ? 'dark' : 'light');
            return;
          }
        }
      } catch (error) {
        console.error('Failed to fetch user neon/light mode preference:', error);
      }

      const storedTheme = localStorage.getItem(storageKey) as 'light' | 'dark';
      if (storedTheme) {
        setTheme(storedTheme);
      } else {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        setTheme(isDark ? 'dark' : 'light');
      }
    };

    fetchUserThemePreference();

    localStorage.setItem(storageKey, theme);
    
    const root = window.document.documentElement;
    
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme, storageKey]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
