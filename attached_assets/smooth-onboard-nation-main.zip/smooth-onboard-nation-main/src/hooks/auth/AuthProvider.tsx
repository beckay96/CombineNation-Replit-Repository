
import { createContext, ReactNode } from 'react';
import { AuthContextType } from './types';
import { useAuthState } from './hooks/useAuthState';
import { useAuthActions } from './hooks/useAuthActions';
import { useAuthInitialization } from './hooks/useAuthInitialization';

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const {
    isAuthenticated,
    setIsAuthenticated,
    isLoading,
    setIsLoading,
    userProfile,
    setUserProfile,
    authChecked,
    setAuthChecked
  } = useAuthState();

  const {
    signIn,
    signUp,
    signOut,
    updateUserProfile
  } = useAuthActions(
    setIsLoading,
    setUserProfile,
    setIsAuthenticated,
    userProfile
  );

  // Initialize auth state
  useAuthInitialization(
    setIsAuthenticated,
    setIsLoading,
    setUserProfile,
    setAuthChecked
  );

  console.log('Current auth state:', { 
    isAuthenticated, 
    isLoading: isLoading && !authChecked, 
    authChecked, 
    hasProfile: !!userProfile 
  });

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        isLoading: isLoading && !authChecked,
        userProfile,
        signIn,
        signUp,
        signOut,
        updateUserProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
