
import { useState } from 'react';
import { UserProfile } from '@/types';

export function useAuthState() {
  // Set initial isLoading to true to avoid UI flashing
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [authChecked, setAuthChecked] = useState<boolean>(false);

  return {
    isAuthenticated,
    setIsAuthenticated,
    isLoading,
    setIsLoading,
    userProfile,
    setUserProfile,
    authChecked,
    setAuthChecked
  };
}
