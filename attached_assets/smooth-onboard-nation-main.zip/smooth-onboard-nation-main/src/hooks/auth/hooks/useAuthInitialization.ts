
import { useEffect } from 'react';
import { UserProfile } from '@/types';
import { useToast } from '@/hooks/use-toast';
import { 
  getCurrentSession,
  setupAuthStateChangeListener,
  signOutUser
} from '../services/authService';
import { fetchUserProfile } from '../services/profileService';
import { ensureProfileExists } from '../services/profileUpdateService';

export function useAuthInitialization(
  setIsAuthenticated: (value: boolean) => void,
  setIsLoading: (value: boolean) => void,
  setUserProfile: (profile: UserProfile | null) => void,
  setAuthChecked: (value: boolean) => void
) {
  const { toast } = useToast();

  useEffect(() => {
    let isMounted = true;
    let authCheckTimeout: NodeJS.Timeout;
    
    // Check authentication status on mount
    const checkAuth = async () => {
      try {
        console.log('Checking authentication status');
        const { data: { session } } = await getCurrentSession();
        
        if (session && isMounted) {
          console.log('User session found, fetching profile');
          try {
            // First ensure the profile exists
            const profileExists = await ensureProfileExists(session.user.id, session.user.email);
            console.log('Profile exists check result:', profileExists);
            
            if (!isMounted) return;
            
            // Now fetch the profile
            const profile = await fetchUserProfile(session.user.id);
            
            if (!isMounted) return;
            
            if (profile) {
              console.log('Profile loaded successfully:', profile);
              setUserProfile(profile);
              setIsAuthenticated(true);
            } else {
              // If still no profile, show an error and sign out
              console.error('Unable to fetch or create profile');
              toast({
                title: 'Authentication error',
                description: 'Unable to load your profile',
                variant: 'destructive',
              });
              
              if (isMounted) {
                await signOutUser();
                setIsAuthenticated(false);
                setUserProfile(null);
              }
            }
          } catch (error) {
            console.error('Profile fetch failed:', error);
            if (isMounted) {
              toast({
                title: 'Authentication error',
                description: 'Failed to load profile data',
                variant: 'destructive',
              });
              setIsAuthenticated(false);
              setUserProfile(null);
            }
          }
        } else {
          console.log('No active session found');
          if (isMounted) {
            // Ensure we set isAuthenticated to false when no session
            setIsAuthenticated(false);
            setUserProfile(null);
          }
        }
      } catch (error) {
        console.error('Authentication check failed:', error);
        if (isMounted) {
          toast({
            title: 'Authentication error',
            description: 'Failed to check authentication status',
            variant: 'destructive',
          });
          // Even on error, make sure to set authentication state
          setIsAuthenticated(false);
          setUserProfile(null);
        }
      } finally {
        // Always finalize loading state, even on errors
        if (isMounted) {
          setIsLoading(false);
          setAuthChecked(true);
          console.log('Auth check completed, loading state set to false');
        }
      }
    };

    // Add an aggressive safety timeout to prevent indefinite loading
    authCheckTimeout = setTimeout(() => {
      if (isMounted) {
        console.log('Auth check safety timeout triggered');
        setIsLoading(false);
        setAuthChecked(true);
        setIsAuthenticated(false); // Force to unauthenticated state if timeout occurs
      }
    }, 5000); // Reduced to 5 seconds for quicker timeout

    // Start auth check immediately
    checkAuth();
    
    // Set up auth state change listener
    const { data: { subscription } } = setupAuthStateChangeListener(
      async (event, session) => {
        console.log('Auth state changed:', event);
        if (event === 'SIGNED_IN' && session && isMounted) {
          console.log('User signed in, fetching profile');
          setIsLoading(true);
          try {
            // First ensure the profile exists
            const profileExists = await ensureProfileExists(
              session.user.id, 
              session.user.email
            );
            console.log('Profile exists check on sign-in:', profileExists);
            
            if (!isMounted) return;
            
            // Now fetch the profile
            const profile = await fetchUserProfile(session.user.id);
            
            if (!isMounted) return;
            
            if (profile) {
              console.log('Profile loaded on sign-in:', profile);
              setUserProfile(profile);
              setIsAuthenticated(true);
            } else {
              // If still no profile, show an error
              console.error('Unable to load profile after sign in');
              if (isMounted) {
                toast({
                  title: 'Authentication error',
                  description: 'Unable to load your profile',
                  variant: 'destructive',
                });
                setIsAuthenticated(false);
                setUserProfile(null);
              }
            }
          } catch (error) {
            console.error('Profile fetch failed after sign in:', error);
            if (isMounted) {
              toast({
                title: 'Authentication error',
                description: 'Failed to load profile after sign in',
                variant: 'destructive',
              });
              setIsAuthenticated(false);
              setUserProfile(null);
            }
          } finally {
            if (isMounted) {
              setIsLoading(false);
              setAuthChecked(true);
              console.log('Sign-in process completed, loading state set to false');
            }
          }
        } else if (event === 'SIGNED_OUT' && isMounted) {
          console.log('User signed out');
          setUserProfile(null);
          setIsAuthenticated(false);
          setIsLoading(false);
          setAuthChecked(true);
        }
      }
    );

    return () => {
      isMounted = false;
      clearTimeout(authCheckTimeout);
      console.log('Cleaning up auth subscription');
      subscription.unsubscribe();
    };
  }, [toast, setIsAuthenticated, setIsLoading, setUserProfile, setAuthChecked]);
}
