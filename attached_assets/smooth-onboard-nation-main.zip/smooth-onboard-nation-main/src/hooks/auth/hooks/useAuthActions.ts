
import { useToast } from '@/hooks/use-toast';
import { UserProfile } from '@/types';
import { 
  signInWithEmail, 
  signUpWithEmail, 
  signOutUser,
} from '../services/authService';
import { updateUserTheme } from '../services/profileService';

export function useAuthActions(
  setIsLoading: (value: boolean) => void,
  setUserProfile: (profile: UserProfile | null) => void,
  setIsAuthenticated: (value: boolean) => void,
  userProfile: UserProfile | null
) {
  const { toast } = useToast();

  const signIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      console.log('Attempting to sign in user:', email);
      const { userProfile, userId } = await signInWithEmail(email, password);
      console.log('Sign in successful, profile:', userProfile, 'userId:', userId);
      
      if (!userProfile || !userProfile.id) {
        console.error('Sign in succeeded but userProfile is invalid:', userProfile);
        throw new Error('Profile retrieval failed during sign in');
      }
      
      setUserProfile(userProfile);
      setIsAuthenticated(true);
      
      // Show confirmation toast
      toast({
        title: 'Signed in successfully',
        description: 'Welcome back!',
      });
      
    } catch (error: any) {
      console.error('Sign in failed:', error);
      toast({
        title: 'Sign in failed',
        description: error.message || 'Please check your email and password',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
      console.log('Sign in process completed, loading state set to false');
    }
  };

  const signUp = async (email: string, password: string, theme: 'light' | 'dark', displayName: string): Promise<UserProfile> => {
    setIsLoading(true);
    try {
      console.log('Attempting to sign up user:', email);
      const { userProfile, userId } = await signUpWithEmail(email, password, theme, displayName);
      console.log('Sign up successful, profile:', userProfile, 'userId:', userId);
      
      // Verify we have a valid user profile with the correct ID
      if (!userProfile || !userProfile.id || userProfile.id !== userId) {
        console.error('Profile creation issue - ID mismatch or missing:', {
          profileId: userProfile?.id,
          authUserId: userId
        });
      }
      
      // These state updates are crucial for the onboarding flow
      setUserProfile(userProfile);
      setIsAuthenticated(true);
      
      // Explicitly return the userProfile
      return userProfile;
    } catch (error: any) {
      console.error('Sign up failed:', error);
      toast({
        title: 'Sign up failed',
        description: error.message || 'Please try again',
        variant: 'destructive',
      });
      throw error;
    } finally {
      setIsLoading(false);
      console.log('Sign up process completed, loading state set to false');
    }
  };

  const signOut = async () => {
    try {
      console.log('Attempting to sign out user');
      await signOutUser();
      setUserProfile(null);
      setIsAuthenticated(false);
      console.log('Sign out successful');
    } catch (error) {
      console.error('Sign out failed:', error);
      throw error;
    }
  };

  const updateUserProfile = async (data: Partial<UserProfile>) => {
    try {
      if (!userProfile) {
        console.error('Cannot update profile: No user profile');
        return;
      }
      
      console.log('Updating user profile with data:', data);
      
      // Update database when necessary
      if ('theme' in data) {
        await updateUserTheme(userProfile.id, data.theme);
      }
      
      // For the frontend, we update all values
      const updatedProfile = { 
        ...userProfile, 
        ...data,
        // Ensure neon_mode is synchronized with theme
        neon_mode: data.theme ? data.theme === 'dark' : userProfile.neon_mode
      };
      
      console.log('Updated profile:', updatedProfile);
      setUserProfile(updatedProfile);
    } catch (error) {
      console.error('Profile update failed:', error);
      throw error;
    }
  };

  return {
    signIn,
    signUp,
    signOut,
    updateUserProfile
  };
}
