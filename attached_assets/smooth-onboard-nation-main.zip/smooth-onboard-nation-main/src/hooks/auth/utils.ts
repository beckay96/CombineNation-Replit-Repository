
import { UserProfile } from '@/types';

// Map database profile to UserProfile type
export const mapDatabaseProfileToUserProfile = (
  profile: any, 
  userId: string
): UserProfile => {
  // neon_mode is used to toggle dark/light theme preferences
  // defaults to true (dark/neon mode) if not set
  
  // Convert neon_mode boolean to theme string
  const theme = profile.neon_mode ? 'dark' : 'light';
  
  console.log('Mapping database profile to UserProfile:', {
    profileId: profile.id,
    providedUserId: userId,
    finalId: profile.id || userId
  });
  
  return {
    id: profile.id || userId, // Ensure id is set, prefer profile.id but fall back to userId
    theme: theme,
    neon_mode: profile.neon_mode,
    created_time: profile.created_time,
    last_active_time: profile.updated_time,
    display_name: profile.display_name,
    first_name: profile.first_name,
    middle_names: profile.middle_names,
    last_name: profile.last_name,
    dob: profile.dob
  };
};
