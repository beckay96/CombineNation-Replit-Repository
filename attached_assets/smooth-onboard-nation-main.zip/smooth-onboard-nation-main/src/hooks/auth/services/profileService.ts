
import { supabase } from '@/integrations/supabase/client';
import { UserProfile } from '@/types';
import { mapDatabaseProfileToUserProfile } from '../utils';

export async function fetchUserProfile(userId: string): Promise<UserProfile | null> {
  if (!userId) {
    console.error('Cannot fetch profile: No user ID provided');
    return null;
  }
  
  try {
    console.log('Fetching profile for user ID:', userId);
    
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error) {
      console.error('Error fetching user profile:', error);
      return null;
    }
    
    if (!profile) {
      console.warn(`No profile found for user ID: ${userId}, profile should have been created already`);
      return null;
    }
    
    console.log('Profile found:', profile);
    return mapDatabaseProfileToUserProfile(profile, userId);
  } catch (error) {
    console.error('Unexpected error fetching user profile:', error);
    return null;
  }
}

// This function is used to create a profile when it doesn't exist
export async function createUserProfile(userId: string, email?: string): Promise<UserProfile | null> {
  if (!userId) {
    console.error('Cannot create profile: No user ID provided');
    return null;
  }

  try {
    console.log('Creating new profile for user ID:', userId);
    
    // First check if profile already exists to prevent duplicate creation
    const { data: existingProfile, error: checkError } = await supabase
      .from('profiles')
      .select('id')
      .eq('id', userId)
      .maybeSingle();
    
    if (checkError) {
      console.error('Error checking for existing profile:', checkError);
      return null;
    }
    
    // If profile already exists, return it instead of trying to create a new one
    if (existingProfile) {
      console.log('Profile already exists, returning existing profile');
      return await fetchUserProfile(userId);
    }
    
    // Default email to empty string if not provided
    const userEmail = email || '';
    
    // Create default profile with light theme
    const { data: profile, error } = await supabase
      .from('profiles')
      .insert({
        id: userId,
        email: userEmail,
        neon_mode: false,
        profile_set_up_complete: false
      })
      .select('*')
      .single();
    
    if (error) {
      console.error('Error creating user profile:', error);
      
      // If the error is because the profile already exists, try to fetch it
      if (error.code === '23505') { // Duplicate key violation
        console.log('Profile already exists, fetching existing profile');
        return await fetchUserProfile(userId);
      }
      
      return null;
    }
    
    console.log('New profile created:', profile);
    return mapDatabaseProfileToUserProfile(profile, userId);
  } catch (error) {
    console.error('Unexpected error creating user profile:', error);
    return null;
  }
}

export async function updateUserTheme(userId: string, theme: 'light' | 'dark'): Promise<void> {
  if (!userId) {
    console.error('Cannot update theme: No user ID provided');
    return;
  }
  
  const neon_mode = theme === 'dark';
  
  try {
    console.log('Updating theme for user ID:', userId, 'to:', theme);
    
    const { error } = await supabase
      .from('profiles')
      .update({ neon_mode })
      .eq('id', userId);
    
    if (error) {
      console.error('Error updating user theme:', error);
      throw error;
    }
    
    console.log('Theme updated successfully');
  } catch (error) {
    console.error('Unexpected error updating user theme:', error);
    throw error;
  }
}

export { fetchUserProfile as getUserProfile };
