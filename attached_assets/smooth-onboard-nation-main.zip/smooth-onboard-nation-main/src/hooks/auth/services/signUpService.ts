
import { supabase } from '@/integrations/supabase/client';
import { UserProfile } from '@/types';
import { mapDatabaseProfileToUserProfile } from '../utils';

export async function signUpWithEmail(
  email: string, 
  password: string,
  theme: 'light' | 'dark',
  displayName: string
): Promise<{userProfile: UserProfile, userId: string}> {
  console.log('Starting signup process for:', email, 'with display name:', displayName);
  
  // Step 1: Create auth user using signUp
  console.log('Creating new auth user');
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        display_name: displayName
      }
    }
  });
  
  if (error) {
    console.error('Auth signup error:', error);
    
    // If the error is about the account already existing, provide a clearer message
    if (error.message.includes('already registered') || 
        error.message.includes('Email address is already taken')) {
      throw new Error('An account with this email already exists. Please log in instead.');
    }
    
    throw error;
  }
  
  if (!data.user) {
    console.error('User data missing after signup');
    throw new Error('User creation failed');
  }
  
  const userId = data.user.id;
  console.log('Auth user created successfully, ID:', userId);
  
  // Step 2: Check if profile already exists with retries
  let existingProfile = null;
  let profileCheckError = null;
  
  // Try up to 3 times with increasing delays
  for (let i = 0; i < 3; i++) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
      
    if (!error && data) {
      existingProfile = data;
      break;
    }
    
    profileCheckError = error;
    // Wait longer between each retry
    await new Promise(resolve => setTimeout(resolve, (i + 1) * 1000));
  }
  
  if (profileCheckError) {
    console.error('Error checking for existing profile:', profileCheckError);
  }
    
  if (existingProfile) {
    console.log('Profile already exists, using existing profile:', existingProfile);
    
    return {
      userProfile: mapDatabaseProfileToUserProfile(existingProfile, userId),
      userId: userId
    };
  }
  
  // Step 3: Create profile record with more robust error handling and retries
  console.log('Creating new profile for user ID:', userId);
  
  // Create profile with the auth user ID as the profile ID
  const profileData = {
    id: userId, // This is crucial! Use the auth user ID as the profile ID
    email: email,
    display_name: displayName,
    neon_mode: theme === 'dark',
    profile_set_up_complete: false
  };
  
  try {
    console.log('Attempting to create profile with data:', profileData);
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .insert(profileData)
      .select('*')
      .single();
    
    if (profileError) {
      console.error('Detailed profile creation error:', {
        code: profileError.code,
        message: profileError.message,
        details: profileError.details,
        hint: profileError.hint
      });
      throw profileError;
    }
    
    if (!profile) {
      throw new Error('Profile creation succeeded but returned no data');
    }
    
    console.log('Profile created successfully on first attempt:', profile);
    // Double-check the ID match
    console.log('Confirming ID match - profile ID:', profile.id, 'auth user ID:', userId);
    
    return {
      userProfile: mapDatabaseProfileToUserProfile(profile, userId),
      userId: userId
    };
  } catch (profileError: any) {
    console.error('Profile creation error:', {
      error: profileError,
      userId,
      email,
      profileData,
      timestamp: new Date().toISOString(),
      environment: import.meta.env.MODE
    });
    
    // Validate required data before retry
    if (!userId || !email) {
      throw new Error('Missing required user data for profile creation');
    }
    
    // If we failed to create the profile but created the auth user,
    // wait a moment and try again (might be a timing issue with auth hooks)
    console.log('Waiting 1 second before retrying profile creation...');
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Second attempt with more detailed error logging
    try {
      const { data: retryProfile, error: retryError } = await supabase
        .from('profiles')
        .insert(profileData)
        .select('*')
        .single();
        
      if (retryError) {
        console.error('Retry profile creation also failed:', retryError);
        throw retryError;
      }
      
      if (!retryProfile) {
        throw new Error('Profile creation succeeded on retry but returned no data');
      }
      
      console.log('Profile created successfully on retry:', retryProfile);
      // Double-check the ID match
      console.log('Confirming ID match - profile ID:', retryProfile.id, 'auth user ID:', userId);
      
      return {
        userProfile: mapDatabaseProfileToUserProfile(retryProfile, userId),
        userId: userId
      };
    } catch (retryError) {
      // Final fallback: check if profile was created despite errors
      const { data: finalCheckProfile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
        
      if (finalCheckProfile) {
        console.log('Profile exists despite errors, using it:', finalCheckProfile);
        // Double-check the ID match
        console.log('Confirming ID match - profile ID:', finalCheckProfile.id, 'auth user ID:', userId);
        
        return {
          userProfile: mapDatabaseProfileToUserProfile(finalCheckProfile, userId),
          userId: userId
        };
      }
      
      throw new Error(`Failed to create profile after multiple attempts: ${retryError}`);
    }
  }
}
