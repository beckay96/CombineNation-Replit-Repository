
import { supabase } from '@/integrations/supabase/client';
import { UserProfile } from '@/types';

// Helper function to create a promise that rejects after a timeout
const withTimeout = <T>(promise: Promise<T> | PromiseLike<T>, timeoutMs: number, errorMessage: string): Promise<T> => {
  // Create a full Promise from any PromiseLike
  const fullPromise = Promise.resolve(promise);
  
  const timeout = new Promise<never>((_, reject) => {
    const id = setTimeout(() => {
      clearTimeout(id);
      reject(new Error(errorMessage));
    }, timeoutMs);
  });

  return Promise.race([fullPromise, timeout]);
};

export interface ProfileDetails {
  firstName?: string;
  middleName?: string;
  lastName?: string;
  dob?: string;
  phoneNumber?: string;
  displayName?: string;
}

export async function updateProfileDetails(userId: string, details: ProfileDetails): Promise<void> {
  if (!userId) {
    throw new Error('Cannot update profile: No user ID provided');
  }
  
  try {
    console.log('Updating profile for user:', userId, 'with details:', details);
    
    // We don't need to verify the user exists - if the ID is valid, the update will work
    // If not, it will just not update any rows (but not error)
    const updatePromise = supabase
      .from('profiles')
      .update({
        first_name: details.firstName,
        middle_names: details.middleName,
        last_name: details.lastName,
        dob: details.dob,
        phone_number: details.phoneNumber,
        display_name: details.displayName || `${details.firstName} ${details.lastName}`,
        profile_set_up_complete: true,
      })
      .eq('id', userId);
    
    const { error } = await withTimeout(
      updatePromise, 
      8000, 
      'Profile update timed out'
    );
    
    if (error) {
      console.error('Error updating profile details:', error);
      throw error;
    }
    
    console.log('Profile updated successfully for user:', userId);
  } catch (error) {
    console.error('Unexpected error updating profile details:', error);
    throw error;
  }
}

export async function checkProfileStatus(userId: string): Promise<boolean> {
  if (!userId) {
    console.log('Cannot check profile status: No user ID provided');
    return false;
  }
  
  try {
    console.log('Checking profile status for user ID:', userId);
    
    const checkPromise = supabase
      .from('profiles')
      .select('profile_set_up_complete, first_name')
      .eq('id', userId)
      .maybeSingle();
    
    const { data, error } = await withTimeout(
      checkPromise,
      5000,
      'Profile status check timed out'
    );
    
    if (error) {
      console.error('Error checking profile setup status:', error);
      return false;
    }
    
    console.log('Profile status check result:', data);
    // Check if first_name exists, if not redirect to profile setup
    if (!data?.first_name) {
      console.log('First name missing, need to show profile setup');
      return false;
    }
    return !!data?.profile_set_up_complete;
  } catch (error) {
    console.error('Unexpected error checking profile setup status:', error);
    return false;
  }
}

export async function ensureProfileExists(userId: string, email?: string): Promise<boolean> {
  if (!userId) {
    console.log('Cannot ensure profile exists: No user ID provided');
    return false;
  }
  
  try {
    console.log('Ensuring profile exists for user ID:', userId);
    
    const checkPromise = supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
      
    const { data: existingProfile, error: checkError } = await withTimeout(
      checkPromise,
      5000,
      'Profile existence check timed out'
    );
    
    if (checkError) {
      console.error('Error checking if profile exists:', checkError);
      return false;
    }
    
    if (existingProfile) {
      console.log('Profile already exists for user:', userId);
      return true;
    }
    
    console.log('Profile does not exist for user, creating one:', userId);
    const createPromise = supabase
      .from('profiles')
      .insert({
        id: userId,
        email: email || '',
        neon_mode: false,
        profile_set_up_complete: false,
      });
    
    const { error: createError } = await withTimeout(
      createPromise,
      5000,
      'Profile creation timed out'
    );
    
    if (createError) {
      console.error('Error creating profile:', createError);
      if (createError.code === '23505') {
        console.log('Profile appears to have been created by another process');
        return true;
      }
      return false;
    }
    
    console.log('Profile created successfully for user:', userId);
    return true;
  } catch (error) {
    console.error('Unexpected error ensuring profile exists:', error);
    return false;
  }
}

// Function to create support relationships for family members
export async function createSupportRelationship(
  thisUserId: string, 
  otherUserId: string, 
  relationshipType: 'Child' | 'Guardian' | 'Spouse',
  supportType?: 'Emergency Contact' | null
): Promise<boolean> {
  if (!thisUserId || !otherUserId) {
    console.error('Cannot create relationship: Missing user IDs');
    return false;
  }
  
  try {
    console.log(`Creating ${relationshipType} relationship between ${thisUserId} and ${otherUserId}`);
    
    let thisToOtherRelation = relationshipType;
    let otherToThisRelation: 'Child' | 'Guardian' | 'Spouse' = 'Child';
    
    // Set reciprocal relationship type
    if (relationshipType === 'Child') {
      otherToThisRelation = 'Guardian';
    } else if (relationshipType === 'Guardian') {
      otherToThisRelation = 'Child';
    } else if (relationshipType === 'Spouse') {
      otherToThisRelation = 'Spouse'; // Spouse is reciprocal
    }
    
    // For support relationships between family members (emergency contacts)
    const isSupportNetwork = !!supportType;
    
    const { error } = await supabase
      .from('relationships')
      .insert([{
        this_user: thisUserId,
        other_user: otherUserId,
        relationship_to_this_user: thisToOtherRelation,
        relationship_to_other_user: otherToThisRelation,
        visibility_level: 'Home', // Default to Home visibility for family
        currently_accepted_friend: true, // Auto-accept for family
        is_support_network: isSupportNetwork,
        support_type: supportType || null
      }]);
    
    if (error) {
      // If the error is a unique constraint violation, the relationship might already exist
      if (error.code === '23505') {
        console.log('Relationship already exists');
        return true;
      }
      console.error('Error creating relationship:', error);
      return false;
    }
    
    console.log('Relationship created successfully');
    return true;
  } catch (error) {
    console.error('Unexpected error creating relationship:', error);
    return false;
  }
}
