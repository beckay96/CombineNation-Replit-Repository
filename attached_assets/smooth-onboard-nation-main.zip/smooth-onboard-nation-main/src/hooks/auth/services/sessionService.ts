
import { supabase } from '@/integrations/supabase/client';

export async function signOutUser(): Promise<void> {
  console.log('Attempting to sign out user');
  const { error } = await supabase.auth.signOut();
  if (error) {
    console.error('Sign out error:', error);
    throw error;
  }
  console.log('User signed out successfully');
}

export async function getCurrentSession() {
  return await supabase.auth.getSession();
}

export function setupAuthStateChangeListener(callback: (event: string, session: any) => void) {
  return supabase.auth.onAuthStateChange(callback);
}
