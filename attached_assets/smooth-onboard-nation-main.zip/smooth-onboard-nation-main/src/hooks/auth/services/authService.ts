
// Re-export all auth services from their dedicated files
export { signInWithEmail } from './signInService';
export { signUpWithEmail } from './signUpService';
export { signOutUser, getCurrentSession, setupAuthStateChangeListener } from './sessionService';
