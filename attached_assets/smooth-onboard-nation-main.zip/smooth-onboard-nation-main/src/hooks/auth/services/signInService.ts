
import { supabase } from '@/integrations/supabase/client';
import { UserProfile } from '@/types';
import { mapDatabaseProfileToUserProfile } from '../utils';

export async function signInWithEmail(email: string, password: string): Promise<{userProfile: UserProfile, userId: string}> {
  console.log('Attempting to sign in with email:', email);
  
  // Step 1: Sign in with email and password using signInWithPassword
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) {
    console.error('Sign in error:', error);
    // Provide a more user-friendly error message
    if (error.message.includes('Invalid login credentials')) {
      throw new Error('The email or password you entered is incorrect. Please try again.');
    }
    throw error;
  }
  
  if (!data.user) {
    console.error('Sign in succeeded but no user data returned');
    throw new Error('Authentication successful but user data missing');
  }
  
  const userId = data.user.id;
  console.log('User authenticated successfully, ID:', userId);
  
  // Step 2: Fetch the user's profile
  const { data: profile, error: profileError } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  
  if (profileError) {
    console.error('Error fetching profile after sign in:', profileError);
    throw new Error('Failed to fetch user profile');
  }
  
  if (!profile) {
    // Create profile if it doesn't exist
    console.log('Creating missing profile during signin for user:', userId);
    
    // Extract display name from auth.user metadata if available
    const displayName = data.user.user_metadata?.display_name || email.split('@')[0];
    
    // Validation check for required data
    if (!userId || !email) {
      throw new Error('Missing required user data for profile creation');
    }
    
    // Default to 'family' role for users created during sign-in
    const defaultRole: UserRole = 'family';
    
    const { data: newProfile, error: insertError } = await supabase
      .from('profiles')
      .insert({
        id: userId,
        email: email,
        display_name: displayName,
        neon_mode: false,
        profile_set_up_complete: false,
        role: defaultRole
      })
      .select('*')
      .single();
    
    if (insertError) {
      console.error('Failed to create profile during signin:', insertError);
      throw new Error('Failed to create profile');
    }
    
    if (!newProfile) {
      console.error('Profile created during sign in but no data returned');
      throw new Error('Profile creation succeeded but returned no data');
    }
    
    console.log('Successfully created profile during signin:', newProfile);
    
    return {
      userProfile: mapDatabaseProfileToUserProfile(newProfile, userId),
      userId: userId
    };
  }
  
  console.log('Using existing profile during signin:', profile);
  
  // Use the role from the database profile
  return {
    userProfile: mapDatabaseProfileToUserProfile(profile, userId),
    userId: userId
  };
}
