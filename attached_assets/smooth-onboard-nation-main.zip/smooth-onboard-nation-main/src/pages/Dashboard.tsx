
import React from 'react';
import { useAuth } from '@/hooks/auth';

const Dashboard = () => {
  const { userProfile } = useAuth();

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Welcome to your Dashboard</h1>
      
      <div className="bg-card p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">Your Profile</h2>
        <div className="grid gap-2">
          <p><span className="font-medium">Display Name:</span> {userProfile?.display_name}</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <div className="bg-card p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Quick Links</h2>
          <div className="space-y-2">
            <p>No quick links available yet.</p>
          </div>
        </div>
        
        <div className="bg-card p-6 rounded-lg shadow-md">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <div className="space-y-2">
            <p>No recent activity yet.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
