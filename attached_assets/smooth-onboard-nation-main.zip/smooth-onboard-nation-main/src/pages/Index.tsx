
import React, { useEffect } from 'react';
import { useAuth } from '@/hooks/auth';
import { useProfileCheck } from '@/hooks/profile/useProfileCheck';
import LoadingState from '@/components/loading/LoadingState';
import ProfileSetup from '@/components/profile/ProfileSetup';
import Dashboard from '@/pages/Dashboard';
import OnboardingInitial from '@/components/onboarding/OnboardingInitial';

const Index = () => {
  const { isAuthenticated, isLoading: authLoading, userProfile } = useAuth();
  
  const {
    checkingProfileStatus,
    needsDisplayName,
    profileSetupComplete,
    handleOnboardingComplete
  } = useProfileCheck(isAuthenticated, userProfile, authLoading);

  // Only show loading when auth is still initializing or we're checking profile status
  // AND we haven't hit our max attempts
  const showLoading = authLoading || checkingProfileStatus;
  
  // Add a fallback if loading takes too long
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (showLoading) {
        console.log('Forcing exit from loading state after timeout');
        // This won't directly update the showLoading state, but it will trigger a re-render
        // which will force the app to show content instead of perpetually loading
        window.location.reload();
      }
    }, 10000); // 10 second timeout as a last resort
    
    return () => clearTimeout(timeoutId);
  }, [showLoading]);
  
  // Loading state
  if (showLoading) {
    console.log('Index: Showing loading state', { authLoading, checkingProfileStatus });
    return <LoadingState />;
  }

  // If authenticated but needs display name, show profile creation step
  if (isAuthenticated && needsDisplayName) {
    console.log('Index: User authenticated but needs display name, showing profile creation');
    return <ProfileSetup onComplete={handleOnboardingComplete} />;
  }

  // Dashboard page (after authentication and profile setup complete)
  if (isAuthenticated && profileSetupComplete) {
    console.log('Index: Showing dashboard');
    return <Dashboard />;
  }

  // If we're here, we need to show the onboarding flow
  // (not loading, not authenticated or profile not complete)
  console.log('Index: Showing onboarding flow', { 
    isAuthenticated, 
    profileSetupComplete,
    authLoading,
    checkingProfileStatus
  });
  
  return <OnboardingInitial onComplete={handleOnboardingComplete} />;
};

export default Index;
