
/**
 * Generates a random password of specified length
 * with a mix of uppercase, lowercase, numbers and special characters
 * 
 * @param length The length of the password (default: 12)
 * @returns A random password string
 */
export function generateRandomPassword(length: number = 12): string {
  const uppercaseChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ'; // excluding I and O which can be confused with 1 and 0
  const lowercaseChars = 'abcdefghijkmnopqrstuvwxyz'; // excluding l which can be confused with 1
  const numberChars = '23456789'; // excluding 0 and 1 which can be confused with O and l
  const specialChars = '!@#$%^&*_-+=?';
  
  const allChars = uppercaseChars + lowercaseChars + numberChars + specialChars;
  
  // Ensure we have at least one of each type of character
  let password = '';
  password += uppercaseChars.charAt(Math.floor(Math.random() * uppercaseChars.length));
  password += lowercaseChars.charAt(Math.floor(Math.random() * lowercaseChars.length));
  password += numberChars.charAt(Math.floor(Math.random() * numberChars.length));
  password += specialChars.charAt(Math.floor(Math.random() * specialChars.length));
  
  // Fill the rest of the password length with random characters
  for (let i = password.length; i < length; i++) {
    password += allChars.charAt(Math.floor(Math.random() * allChars.length));
  }
  
  // Shuffle the password to make it more random
  return password.split('').sort(() => 0.5 - Math.random()).join('');
}
