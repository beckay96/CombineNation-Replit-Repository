
import React from 'react';
import { useTheme } from '@/hooks/useTheme';
import ThemeToggle from './ThemeToggle';
import StepIndicator from './onboarding/StepIndicator';
import StepNavigation from './onboarding/StepNavigation';
import OnboardingContent from './onboarding/OnboardingContent';
import { useOnboarding } from '@/hooks/onboarding';

interface OnboardingFlowProps {
  onComplete: () => void;
  initialStep?: number;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, initialStep = 0 }) => {
  const { theme } = useTheme();
  const {
    email,
    setEmail,
    password,
    setPassword,
    confirmPassword,
    setConfirmPassword,
    displayName,
    setDisplayName,
    step,
    isProcessing,
    isLoading,
    getSteps,
    handleRoleSelect,
    handleNext,
    handleBack,
    handleSignup,
    handleProfileSubmit,
    handleFamilySetupComplete,
    handleSchoolSetupComplete,
    accountExists,
    activeAuthTab
  } = useOnboarding(onComplete, initialStep);

  const stepTitles = getSteps();

  // Add a log to help track the current step for debugging
  console.log('Current onboarding step:', step, 'accountExists:', accountExists, 'activeAuthTab:', activeAuthTab);

  // Only show step indicator when not on the initial step with login tab active
  const showStepIndicator = !(step === 0 && activeAuthTab === 'login');

  return (
    <div className="w-full max-w-5xl mx-auto px-6 py-12 flex flex-col items-center">
      {/* Only show step indicator when not on login tab */}
      {showStepIndicator && (
        <StepIndicator steps={stepTitles} currentStep={step} />
      )}

      <OnboardingContent 
        step={step}
        email={email}
        setEmail={setEmail}
        password={password}
        setPassword={setPassword}
        confirmPassword={confirmPassword}
        setConfirmPassword={setConfirmPassword}
        displayName={displayName}
        setDisplayName={setDisplayName}
        onOptionSelect={handleRoleSelect}
        onSignupSubmit={handleSignup}
        onProfileSubmit={handleProfileSubmit}
        onFamilySetupComplete={handleFamilySetupComplete}
        onSchoolSetupComplete={handleSchoolSetupComplete}
        isLoading={isLoading}
        isProcessing={isProcessing}
        accountExists={accountExists}
        activeAuthTab={activeAuthTab}
      />

      {/* Show navigation buttons for appropriate steps */}
      {(step === 2 || (step === 0 && activeAuthTab !== 'login')) && (
        <StepNavigation
          currentStep={step}
          totalSteps={stepTitles.length}
          onNext={handleNext}
          onBack={handleBack}
          hideNext={step === 0} // Hide next on account creation step (use form submission)
        />
      )}

      <div className="mt-12 flex items-center gap-3">
        <span className="text-sm text-muted-foreground font-opensans">Neon or Light Mode?:</span>
        <ThemeToggle />
      </div>
    </div>
  );
}

export default OnboardingFlow;
