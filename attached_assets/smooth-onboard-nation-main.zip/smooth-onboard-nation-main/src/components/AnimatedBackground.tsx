
import React from 'react';
import { useTheme } from '@/hooks/useTheme';

const AnimatedBackground: React.FC = () => {
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <div className="fixed inset-0 -z-10 h-full w-full overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background to-background via-background/90 z-10" />
      
      {/* Primary spotlight */}
      <div 
        className={`absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 animate-spotlight pointer-events-none opacity-20 ${
          isDark ? 'bg-primary/30' : 'bg-primary/20'
        }`} 
        style={{
          height: '600px',
          width: '900px', 
          borderRadius: '900px',
          filter: 'blur(100px)',
        }}
      />
      
      {/* Secondary spotlight */}
      <div 
        className={`absolute left-[25%] top-1/3 -translate-x-1/2 -translate-y-1/2 animate-spotlight pointer-events-none opacity-20 animation-delay-700 ${
          isDark ? 'bg-secondary/30' : 'bg-secondary/20'
        }`} 
        style={{
          height: '500px',
          width: '700px', 
          borderRadius: '700px',
          filter: 'blur(100px)',
          animationDelay: '0.7s',
        }}
      />
      
      {/* Tertiary spotlight */}
      <div 
        className={`absolute left-[75%] top-2/3 -translate-x-1/2 -translate-y-1/2 animate-spotlight pointer-events-none opacity-20 animation-delay-1000 ${
          isDark ? 'bg-tertiary/30' : 'bg-tertiary/20'
        }`} 
        style={{
          height: '400px',
          width: '600px', 
          borderRadius: '600px',
          filter: 'blur(100px)',
          animationDelay: '1s',
        }}
      />
      
      {/* Quaternary spotlight */}
      <div 
        className={`absolute left-[60%] top-1/4 -translate-x-1/2 -translate-y-1/2 animate-spotlight pointer-events-none opacity-20 animation-delay-1300 ${
          isDark ? 'bg-quaternary/30' : 'bg-quaternary/20'
        }`} 
        style={{
          height: '300px',
          width: '500px', 
          borderRadius: '500px',
          filter: 'blur(100px)',
          animationDelay: '1.3s',
        }}
      />
    </div>
  );
};

export default AnimatedBackground;
