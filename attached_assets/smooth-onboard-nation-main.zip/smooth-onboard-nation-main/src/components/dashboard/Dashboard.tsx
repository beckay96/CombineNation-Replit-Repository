
import React from 'react';
import AnimatedBackground from '@/components/AnimatedBackground';
import Header from '@/components/Header';
import { UserProfile } from '@/types';

interface DashboardProps {
  userProfile?: UserProfile;
}

const Dashboard: React.FC<DashboardProps> = ({ userProfile }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <AnimatedBackground />
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-6">
        <div className="max-w-4xl w-full mx-auto text-center space-y-6 animate-fade-in">
          <div className="inline-block mb-3 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium animate-fade-in">
            Welcome{userProfile?.display_name ? `, ${userProfile.display_name}` : ''}
          </div>
          <h1 className="text-4xl md:text-5xl font-bold tracking-tight animate-fade-in animate-delay-100">
            Your CombineNation journey begins here
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto animate-fade-in animate-delay-200">
            Your personalised dashboard is coming soon. We're excited to have you join our community.
          </p>
          <div className="pt-6 animate-fade-in animate-delay-300">
            <button className="bg-primary text-primary-foreground px-8 py-3 rounded-lg font-medium hover:bg-primary/90 transition-all">
              Explore Features
            </button>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
