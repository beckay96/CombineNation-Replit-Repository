
import React from 'react';
import AnimatedBackground from '@/components/AnimatedBackground';
import Header from '@/components/Header';
import OnboardingFlow from '@/components/OnboardingFlow';

interface ProfileSetupProps {
  onComplete: () => void;
}

const ProfileSetup: React.FC<ProfileSetupProps> = ({ onComplete }) => {
  return (
    <div className="min-h-screen flex flex-col">
      <AnimatedBackground />
      <Header />
      <main className="flex-1 flex flex-col items-center justify-center p-6">
        <OnboardingFlow onComplete={onComplete} initialStep={1} />
      </main>
    </div>
  );
};

export default ProfileSetup;
