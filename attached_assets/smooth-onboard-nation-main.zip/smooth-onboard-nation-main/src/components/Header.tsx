
import React from 'react';
import ThemeToggle from './ThemeToggle';
import { useAuth } from '@/hooks/auth';
import { Button } from './ui/button';
import { LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Header: React.FC = () => {
  const {
    isAuthenticated,
    signOut,
    userProfile,
    updateUserProfile
  } = useAuth();
  
  const { toast } = useToast();
  
  const handleThemeChange = (theme: 'light' | 'dark') => {
    if (isAuthenticated && userProfile) {
      updateUserProfile({
        theme
      });
    }
  };
  
  const handleSignOut = async () => {
    try {
      console.log('Attempting to sign out user');
      await signOut();
      toast({
        title: "Signed out",
        description: "You have been successfully signed out."
      });
    } catch (error) {
      console.error('Sign out failed:', error);
      toast({
        title: "Sign out failed",
        description: "There was a problem signing you out.",
        variant: "destructive"
      });
    }
  };
  
  return <header className="w-full py-4 px-6 flex items-center justify-between z-10 transition-all duration-300">
      <div className="flex items-center">
        <h1 className="text-xl font-medium tracking-tight font-dyslexic">
          <span className="text-primary font-semibold">Combine</span>
          <span>Nation</span>
        </h1>
      </div>
      <div className="flex items-center space-x-4">
        <ThemeToggle onThemeChange={handleThemeChange} />
        {isAuthenticated && <Button variant="outline" onClick={handleSignOut} className="flex items-center gap-2">
            <LogOut className="h-4 w-4" />
            <span>Sign Out</span>
          </Button>}
      </div>
    </header>;
};

export default Header;
