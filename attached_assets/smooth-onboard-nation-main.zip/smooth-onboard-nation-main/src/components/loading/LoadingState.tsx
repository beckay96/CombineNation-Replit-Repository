
import React, { useState, useEffect } from 'react';
import AnimatedBackground from '@/components/AnimatedBackground';
import Header from '@/components/Header';
import { Button } from '@/components/ui/button';
import { RefreshCw, LogOut } from 'lucide-react';
import { useAuth } from '@/hooks/auth';
import { useToast } from '@/hooks/use-toast';

interface LoadingStateProps {
  message?: string;
  timeout?: number; // Timeout in milliseconds
}

const LoadingState: React.FC<LoadingStateProps> = ({ 
  message = 'Loading your profile...', 
  timeout = 3000 // Default 3 second timeout
}) => {
  const [isTimedOut, setIsTimedOut] = useState(false);
  const { signOut, isAuthenticated } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsTimedOut(true);
      toast({
        title: "Loading timeout",
        description: "It's taking longer than expected to load your profile",
        variant: "default"
      });
    }, timeout);

    return () => clearTimeout(timer);
  }, [timeout, toast]);

  const handleRefresh = () => {
    window.location.reload();
  };

  const handleSignOut = async () => {
    try {
      console.log('Attempting to sign out user');
      // Check if user is already authenticated before attempting to sign out
      if (isAuthenticated) {
        console.log('User is authenticated, proceeding with sign out');
        await signOut();
        console.log('Sign out function completed');
        toast({
          title: "Signed out",
          description: "You've been successfully signed out"
        });
      } else {
        console.log('User appears to be already signed out');
        toast({
          title: "Already signed out",
          description: "You're not currently signed in"
        });
      }
      // Force reload regardless to reset any stuck state
      console.log('Forcing page reload');
      window.location.href = '/';
    } catch (error) {
      console.error("Sign out failed:", error);
      toast({
        title: "Sign out failed",
        description: "Please try refreshing the page",
        variant: "destructive"
      });
      // Force reload even on error as a last resort
      setTimeout(() => window.location.reload(), 1500);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <AnimatedBackground />
      <Header />
      <div className="flex-1 flex items-center justify-center flex-col">
        <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin mb-4" />
        <p className="text-muted-foreground mb-6">{message}</p>
        
        {isTimedOut && (
          <div className="flex flex-col gap-4 items-center mt-2">
            <p className="text-sm text-muted-foreground text-center max-w-md">
              Looks like things are taking longer than expected. You can try refreshing the page or signing out if you're stuck.
            </p>
            <div className="flex gap-3">
              <Button onClick={handleRefresh} variant="outline" className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4" />
                <span>Refresh</span>
              </Button>
              <Button onClick={handleSignOut} variant="default" className="flex items-center gap-2">
                <LogOut className="h-4 w-4" />
                <span>Sign Out</span>
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoadingState;
