
import React from 'react';
import { GraduationCap, Users, Heart, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAppState } from '@/hooks/appState/AppStateContext';

interface RoleSelectionProps {
  selectedOptionIndex: number | null;
  onOptionSelect: (optionIndex: number) => void;
}

const RoleCard: React.FC<{
  optionIndex: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  isSelected: boolean;
  onClick: () => void;
}> = ({ optionIndex, title, description, icon, isSelected, onClick }) => {
  return (
    <div
      className={cn(
        "relative rounded-2xl p-6 flex flex-col items-center transition-all duration-300 cursor-pointer transform hover:scale-105",
        "border border-border",
        isSelected
          ? "bg-primary/10 border-primary shadow-lg shadow-primary/10"
          : "bg-card hover:bg-card/80"
      )}
      onClick={onClick}
    >
      <div
        className={cn(
          "w-16 h-16 rounded-full flex items-center justify-center mb-5 transition-all duration-300",
          isSelected
            ? "bg-primary text-primary-foreground"
            : "bg-muted text-muted-foreground"
        )}
      >
        {icon}
      </div>
      <h3 className="text-xl font-medium mb-2">{title}</h3>
      <p className="text-center text-muted-foreground">{description}</p>
      <div
        className={cn(
          "absolute top-3 right-3 w-4 h-4 rounded-full border-2 transition-all duration-300",
          isSelected
            ? "border-primary bg-primary"
            : "border-muted bg-transparent"
        )}
      ></div>
    </div>
  );
};

const RoleSelection: React.FC<RoleSelectionProps> = ({
  selectedOptionIndex,
  onOptionSelect,
}) => {
  const {
    setIsAddingSchool,
    setIsAddingFamily,
  } = useAppState();

  // Update the app state based on option selection
  const handleOptionSelect = (optionIndex: number) => {
    // Update app state flags based on selected option
    // These flags determine what steps are shown in the onboarding flow
    
    // Option 0: Educator (work)
    // Option 1: Family
    // Option 2: Both
    // Option 3: Solo
    
    if (optionIndex === 0 || optionIndex === 2) {
      // Educator or Both
      setIsAddingSchool(true);
    } else {
      setIsAddingSchool(false);
    }

    if (optionIndex === 1 || optionIndex === 2) {
      // Family or Both
      setIsAddingFamily(true);
    } else {
      setIsAddingFamily(false);
    }

    // Pass the selection to the parent component
    onOptionSelect(optionIndex);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-5xl animate-fade-in">
      <RoleCard
        optionIndex={0}
        title="I'm here for work"
        description="Resources for educators, teachers, and education professionals."
        icon={<GraduationCap size={32} />}
        isSelected={selectedOptionIndex === 0}
        onClick={() => handleOptionSelect(0)}
      />
      <RoleCard
        optionIndex={1}
        title="I'm here for family"
        description="Tools and resources for parents, guardians, and family members."
        icon={<Heart size={32} />}
        isSelected={selectedOptionIndex === 1}
        onClick={() => handleOptionSelect(1)}
      />
      <RoleCard
        optionIndex={2}
        title="I'm here for both!"
        description="Access to all resources for both educators and family members."
        icon={<Users size={32} />}
        isSelected={selectedOptionIndex === 2}
        onClick={() => handleOptionSelect(2)}
      />
      <RoleCard
        optionIndex={3}
        title="I'm here for myself"
        description="Personal resources and tools just for individual users."
        icon={<User size={32} />}
        isSelected={selectedOptionIndex === 3}
        onClick={() => handleOptionSelect(3)}
      />
    </div>
  );
};

export default RoleSelection;
